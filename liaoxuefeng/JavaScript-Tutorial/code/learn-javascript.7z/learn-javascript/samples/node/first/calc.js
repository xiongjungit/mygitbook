'use strict';

console.log(100 + 200 + 300);
