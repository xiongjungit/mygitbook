require('babel-core/register')({
    presets: ['stage-3']
});
